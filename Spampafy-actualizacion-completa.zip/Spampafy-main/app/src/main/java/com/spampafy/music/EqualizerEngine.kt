package com.spampafy.music

import android.media.audiofx.Equalizer

object EqualizerEngine {
    @Volatile private var equalizer: Equalizer? = null

    @Synchronized
    fun attach(sessionId: Int) {
        if (sessionId <= 0) return
        try {
            equalizer?.release()
            equalizer = Equalizer(0, sessionId).apply { enabled = true }
        } catch (_: Exception) {
            equalizer = null
        }
    }

    @Synchronized
    fun detach() {
        try { equalizer?.release() } catch (_: Exception) {}
        equalizer = null
    }

    @Synchronized
    fun setPreset(index: Short) {
        try {
            val eq = equalizer ?: return
            if (eq.numberOfPresets.toInt() > 0) eq.usePreset(index.coerceIn(0.toShort(), (eq.numberOfPresets - 1).toShort()))
            eq.enabled = true
        } catch (_: Exception) {}
    }

    fun presetNames(): List<String> {
        return try {
            val eq = equalizer ?: return emptyList()
            (0 until eq.numberOfPresets.toInt()).map { eq.getPresetName(it.toShort()).toString() }
        } catch (_: Exception) { emptyList() }
    }

    fun isAvailable(): Boolean = equalizer != null
}
