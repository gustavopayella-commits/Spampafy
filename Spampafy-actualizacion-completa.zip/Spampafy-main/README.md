# Spampafy

Actualización de Spampafy con navegación inferior estilo reproductor musical.

## Funciones incluidas
- Inicio, búsqueda, biblioteca y favoritos.
- Lectura de canciones disponibles en el dispositivo (requiere permiso de audio).
- Importación de archivos mediante el selector del sistema y persistencia de sus permisos.
- Listas de reproducción guardadas localmente.
- Cola de reproducción con controles para cambiar el orden.
- Ecualizador con perfiles disponibles en el dispositivo.
- Conversión OPUS conservada en 32/48/64/96 kbps.
- Reproducción mediante MediaSessionService y pantalla PlayerActivity conservadas.

## Compilar
Abrir el repositorio en GitHub y ejecutar el workflow de GitHub Actions. Revisar el resultado antes de instalar el APK.
